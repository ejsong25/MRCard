package com.mrCard;

public class CardDetailDTO {

	private String cardName;
	private int pTrans;
	private int mart;
	private int cStore;
	private int dStore;
	private int cafe;
	private int pGas;
	private int amf;
	
	
	public String getCardName() {
		return cardName;
	}
	public void setCardName(String cardName) {
		this.cardName = cardName;
	}
	public int getpTrans() {
		return pTrans;
	}
	public void setpTrans(int pTrans) {
		this.pTrans = pTrans;
	}
	public int getMart() {
		return mart;
	}
	public void setMart(int mart) {
		this.mart = mart;
	}
	public int getcStore() {
		return cStore;
	}
	public void setcStore(int cStore) {
		this.cStore = cStore;
	}
	public int getdStore() {
		return dStore;
	}
	public void setdStore(int dStore) {
		this.dStore = dStore;
	}
	public int getCafe() {
		return cafe;
	}
	public void setCafe(int cafe) {
		this.cafe = cafe;
	}
	public int getpGas() {
		return pGas;
	}
	public void setpGas(int pGas) {
		this.pGas = pGas;
	}
	public int getAmf() {
		return amf;
	}
	public void setAmf(int amf) {
		this.amf = amf;
	}
	
	

	
	
	
	
}
