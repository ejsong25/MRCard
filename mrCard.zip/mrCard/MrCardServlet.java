package com.mrCard;

import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.sql.Connection;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mrCard.CustomInfo;
import com.util.MyUtil;

public class MrCardServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}


	protected void forward(HttpServletRequest req, HttpServletResponse resp, String url) throws ServletException, IOException {

		RequestDispatcher rd = req.getRequestDispatcher(url); // ��������� ���� url ���⿡ ������

		rd.forward(req, resp);

	}


	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		req.setCharacterEncoding("UTF-8");
		String cp = req.getContextPath();

		Connection conn = DBConn_mr.getConnection();

		MyUtil myUtil = new MyUtil();

		String uri = req.getRequestURI(); // study���� �������� �ּ�

		String url;

		if(uri.indexOf("index.do")!=-1) {

			url = "/aMr/filter_index.jsp";
			forward(req, resp, url);

		} else if (uri.indexOf("signup.do")!=-1) {

			url = "/aMr/signup.jsp";
			forward(req, resp, url);


		} else if(uri.indexOf("signup_ok.do")!=-1) {

			SignUpDTO dto = new SignUpDTO();

			SignUpDAO dao = new SignUpDAO(conn);

			dto.setId(req.getParameter("id"));
			dto.setPwd(req.getParameter("pwd"));
			dto.setName(req.getParameter("name"));
			dto.setJumin(req.getParameter("jumin"));
			dto.setAddress(req.getParameter("address"));

			dao.insertData(dto);

			url = cp + "/aMr/index.jsp";
			resp.sendRedirect(url);


		} else if(uri.indexOf("login.do")!=-1) {

			url = "/aMr/login.jsp";

			forward(req, resp, url);						

		} else if(uri.indexOf("login_ok.do")!=-1) {	

			loginDAO dao = new loginDAO(conn);

			String id = req.getParameter("id");
			String pwd = req.getParameter("pwd");

			loginDTO dto = dao.getReadData(id);

			if(dto==null || (!dto.getPwd().equals(pwd))) {

				req.setAttribute("message", 
						"���̵� �Ǵ� �н����带 ��Ȯ�� �Է��ϼ���.");

				url = "/aMr/login.jsp";
				forward(req, resp, url);
				return;

			}

			HttpSession session = req.getSession();

			CustomInfo info = new CustomInfo();

			info.setId(dto.getId());
			info.setName(dto.getName());

			session.setAttribute("customInfo", info);

			url = "/aMr/filter_index.jsp";
			forward(req, resp, url);		

		} else if(uri.indexOf("searchpw.do")!=-1) {


			url = "/aMr/searchPw.jsp";

			forward(req, resp, url);

		} else if(uri.indexOf("searchpw_ok.do")!=-1) {	

			loginDAO dao = new loginDAO(conn);

			String id = req.getParameter("id");
			String jumin = req.getParameter("jumin");

			loginDTO dto = dao.getReadData(id);

			if(dto==null || (!dto.getJumin().equals(jumin))) {

				req.setAttribute("message", 
						"ȸ�������� �������� �ʽ��ϴ�.");

				url = "/aMr/login.jsp";
				forward(req, resp, url);
				return;

			}

			if((dto.getJumin().equals(jumin))) {

				req.setAttribute("message", 
						"��й�ȣ��"+ "[" + dto.getPwd() + "]" + "�Դϴ�.");

				url = "/aMr/login.jsp";
				forward(req, resp, url);
				return; 

			}

		} else if(uri.indexOf("searchid.do")!=-1) {


			url = "/aMr/searchId.jsp";

			forward(req, resp, url);			

		} else if(uri.indexOf("searchid_ok.do")!=-1) {

			loginDAO dao = new loginDAO(conn);

			String name = req.getParameter("name");
			String jumin = req.getParameter("jumin");

			loginDTO dto = dao.getReadData2(name);

			if(dto==null || (!dto.getJumin().equals(jumin))) {

				req.setAttribute("message", 
						"ȸ�������� �������� �ʽ��ϴ�.");

				url = "/aMr/login.jsp";
				forward(req, resp, url);
				return;

			}	

			if((dto.getJumin().equals(jumin))) {

				req.setAttribute("message", 
						"���̵��"+ "[" + dto.getId() + "]" + "�Դϴ�.");

				url = "/aMr/login.jsp";
				forward(req, resp, url);
				return; 

			}

		} else if(uri.indexOf("logout.do")!=-1) {	

			HttpSession session = req.getSession();

			session.removeAttribute("customInfo");
			session.invalidate();

			url = cp + "/aMr/index.jsp";
			resp.sendRedirect(url);

		} else if(uri.indexOf("created.do")!=-1) { // ���ԵǾ� ������

			HttpSession session = req.getSession();

			CustomInfo info = (CustomInfo)session.getAttribute("customInfo"); // Ŭ�������� �̷��� ���

			if(info == null) {

				url = "/aMr/login.jsp";
				forward(req, resp, url);
				return;

			}

			url = "/aMr/created.jsp";

			forward(req, resp, url);

		} else if(uri.indexOf("created_ok.do")!=-1) {

			MrCardDAO dao = new MrCardDAO(conn);
			MrCardDTO dto = new MrCardDTO();

			int maxNum = dao.getMaxNum();

			dto.setNum(maxNum + 1);
			dto.setId(req.getParameter("id"));
			dto.setPwd(req.getParameter("pwd"));
			dto.setName(req.getParameter("name"));
			dto.setSubject(req.getParameter("subject"));
			dto.setContent(req.getParameter("content"));

			dao.insertData(dto);

			url = cp + "/mr/list.do"; // �����̷�Ʈ�� ���� �ּ�(������� ���� �ּ�)
			resp.sendRedirect(url);

		} else if(uri.indexOf("list.do")!=-1) {

			MrCardDAO dao = new MrCardDAO(conn);

			//����¡
			String pageNum = req.getParameter("pageNum");
			int currentPage = 1;

			if(pageNum!=null) {

				currentPage = Integer.parseInt(pageNum);
			}

			int dataCount = dao.getDataCount();

			int numPerPage = 3;
			int totalPage = myUtil.getPageCount(numPerPage, dataCount);

			if(currentPage>totalPage) {

				currentPage = totalPage;
			}

			int start = (currentPage-1)*numPerPage+1;
			int end = currentPage * numPerPage;
			
			List<MrCardDTO> lists = dao.getLists(start, end);
			
			String listUrl = cp + "/mr/list.do"; // ���� �ּ� ����
			String pageIndexList = myUtil.pageIndexList(currentPage, totalPage, listUrl);
			
			String articleUrl = cp + "/mr/article.do?pageNum=" + currentPage;
			
			String searchKey = req.getParameter("searchKey");
			//����Ʈ
			List<FaqDTO> qalists = null;
			//searchKey ���� ��
			if(searchKey != null) {
				
				FaqDAO dao2 = new FaqDAO(conn);
				qalists = dao2.getLists(searchKey);
			
			//searchKey ���� ��
			}else if(uri.indexOf("searchKey") == -1){
				
				FaqDAO dao2 = new FaqDAO(conn);
				qalists = dao2.getLists();
			}
			
			// list.jsp �� �������� ������
			req.setAttribute("lists", lists);
			req.setAttribute("pageIndexList", pageIndexList);
			req.setAttribute("dataCount", dataCount);
			req.setAttribute("articleUrl", articleUrl);
			//qaList
			req.setAttribute("qalists", qalists);

			url = "/aMr/list.jsp";
			forward(req, resp, url);

		} else if (uri.indexOf("article.do")!=-1) {

			MrCardDAO dao = new MrCardDAO(conn);

			int num = Integer.parseInt(req.getParameter("num"));
			String pageNum = req.getParameter("pageNum");

			dao.updateHitCount(num);

			MrCardDTO dto = dao.getReadData(num);

			if(dto==null) {
				url = cp + "/mr/list.do";
				resp.sendRedirect(url);
			}

			String param = "pageNum=" + pageNum;

			req.setAttribute("dto", dto);
			req.setAttribute("params", param);

			url = "/aMr/article.jsp";
			forward(req, resp, url);

		} else if (uri.indexOf("updated.do")!=-1) {

			MrCardDAO dao = new MrCardDAO(conn);

			int num = Integer.parseInt(req.getParameter("num"));
			String pageNum = req.getParameter("pageNum");

			MrCardDTO dto = dao.getReadData(num);

			if(dto==null) {

				url = cp + "/mr/list.do";
				resp.sendRedirect(url);

			}

			String param = "pageNum=" + pageNum;

			req.setAttribute("dto", dto);
			req.setAttribute("pageNum", pageNum);
			req.setAttribute("params", param);

			url = "/aMr/updated.jsp";
			forward(req, resp, url);

		} else if (uri.indexOf("updated_ok.do")!=-1) {

			String pageNum = req.getParameter("pageNum");

			MrCardDAO dao = new MrCardDAO(conn);

			MrCardDTO dto = new MrCardDTO();

			dto.setNum(Integer.parseInt(req.getParameter("num")));
			dto.setSubject(req.getParameter("subject"));
			dto.setName(req.getParameter("name"));
			dto.setId(req.getParameter("id"));
			dto.setPwd(req.getParameter("pwd"));
			dto.setContent(req.getParameter("content"));

			dao.updateData(dto);

			String param = "pageNum=" + pageNum;

			url = cp + "/mr/list.do?" + param;
			resp.sendRedirect(url); // �����ϰ� ������ ��


		} else if (uri.indexOf("deleted_ok.do")!=-1) {

			MrCardDAO dao = new MrCardDAO(conn);

			int num = Integer.parseInt(req.getParameter("num"));
			String pageNum = req.getParameter("pageNum");

			dao.deleteData(num);

			String param = "pageNum=" + pageNum;

			url = cp + "/mr/list.do?" + param;
			resp.sendRedirect(url);

		} else if(uri.indexOf("cardList.do") != -1) {
			CardDAO dao = new CardDAO(conn);

			List<CardDTO> lists = dao.getLists();

			req.setAttribute("lists", lists);

			url = "/aMr/cardList.jsp";
			forward(req, resp, url);

		//ī�� �ؽ��±� Ŭ����
		} else if(uri.indexOf("searchCard.do") != -1) {
			String searchKey = req.getParameter("searchKey");
			CardDAO dao = new CardDAO(conn);

			List<CardDTO> lists = dao.getLists(searchKey);

			req.setAttribute("lists", lists);
			url = "/aMr/cardList.jsp";
			forward(req, resp, url);

		// �ؽ��±� Ŭ����
		} else if(uri.indexOf("searchfaq.do") != -1) {
			
			String searchKey = req.getParameter("searchKey");
			
			FaqDAO dao = new FaqDAO(conn);

			List<FaqDTO> lists = dao.getLists(searchKey);

			req.setAttribute("lists2", lists);
			url = "/aMr/faqlist.jsp";
			forward(req, resp, url);

		} else if(uri.indexOf("cardDetails.do")!=-1){

			String cardName = req.getParameter("cardName");

			CardDetailDAO dao = new CardDetailDAO(conn);				
			CardDetailDTO dto = dao.getCardDetail(cardName);


			if(dto==null) {
				url = cp + "/mr/cardList.do";
				//resp.sendRedirect(url);				
			}

			req.setAttribute("dto", dto);
			url = "/aMr/cardDetails.jsp";

			forward(req, resp, url);
			
		}else if(uri.indexOf("cardList.do") != -1) {
			
			CardDAO dao = new CardDAO(conn);
			
			List<CardDTO> lists = dao.getLists();
			
			req.setAttribute("lists", lists);
			
			url = "/aMr/cardList.jsp";
			forward(req, resp, url);
		
		} else if(uri.indexOf("searchCard.do") != -1) {
			
			String searchKey = req.getParameter("searchKey");
			CardDAO dao = new CardDAO(conn);

			List<CardDTO> lists = dao.getLists(searchKey);

			req.setAttribute("lists", lists);
			url = "/aMr/cardList.jsp";
			forward(req, resp, url);
			
		} else if(uri.indexOf("created.do")!=-1) { // ���ԵǾ� ������
			
			HttpSession session = req.getSession();
			
			CustomInfo info = (CustomInfo)session.getAttribute("customInfo"); // Ŭ�������� �̷��� ���
			
			if(info == null) {
				
				url = "/aMr/login.jsp";
				forward(req, resp, url);
				return;
				
			}

			url = "/aMr/created.jsp";
			forward(req, resp, url);

		} else if(uri.indexOf("userUpdated.do") != -1) {

			String id = req.getParameter("id");
			
			MyPageDAO dao = new MyPageDAO(conn);
			loginDTO dto = dao.getReadData(id);
			
			req.setAttribute("dto", dto);
			
			url = "/aMr/userUpdated.jsp";
			forward(req, resp, url);
			
		} else if(uri.indexOf("userUpdated_ok.do") != -1) {
			
			MyPageDAO dao = new MyPageDAO(conn);
			loginDTO dto = new loginDTO();
			
			dto.setId(req.getParameter("id"));
			dto.setPwd(req.getParameter("pwd"));
			dto.setName(req.getParameter("name"));
			dto.setAddress(req.getParameter("address"));
			dto.setJumin(req.getParameter("jumin"));
			
			dao.updateData(dto);
			
			url = "/aMr/filter_index.jsp";
			forward(req, resp, url);
			
		} else if(uri.indexOf("myPage.do") != -1) {
			
			String id = req.getParameter("id");
			
			MyPageDAO dao = new MyPageDAO(conn);
			loginDTO dto = dao.getReadData(id);
			MyCardDAO dao_mc = new MyCardDAO(conn);
			
			int cardCount = dao_mc.getCardCount(id);
			String cardName = dao_mc.getcardName(id);
			String cAccount = dao_mc.getcAccount(id);
			String name = dao_mc.getName(id);
			int payDay = dao_mc.getpayDay(id);
			
			req.setAttribute("cardCount", cardCount);
			req.setAttribute("dto", dto);
			req.setAttribute("cardName", cardName);
			req.setAttribute("cAccount", cAccount);
			req.setAttribute("payDay", payDay);
			req.setAttribute("name", name);
			
			url = "/aMr/userMyPage.jsp";
			forward(req, resp, url);
			
		} else if(uri.indexOf("payUpdated.do") != -1) {
			
			String id = req.getParameter("id");
			
			MyPageDAO dao = new MyPageDAO(conn);
			loginDTO dto = dao.getReadData(id);
			MyCardDAO dao_mc = new MyCardDAO(conn);
			
			int payDay = dao_mc.getpayDay(id);
			
			req.setAttribute("payDay", payDay);
			
			url = "/aMr/payUpdated.jsp";
			forward(req, resp, url);
			
		} else if(uri.indexOf("payUpdated_ok.do") != -1) {
			
			String id = req.getParameter("id");
			int payDay = Integer.parseInt(req.getParameter("payDay")) ;
			MyCardDAO dao = new MyCardDAO(conn);
			MyCardDTO dto = dao.getReadData(id);
			
			//int payDay = dao.getpayDay(id);
			int cardCount = dao.getCardCount(id);
		
			req.setAttribute("payDay", payDay);
			req.setAttribute("dto", dto);
			dto.setPayDay(Integer.parseInt(req.getParameter("payDay")));
			String cardName = dao.getcardName(id);
			String cAccount = dao.getcAccount(id);
			
			req.setAttribute("cardCount", cardCount);
			req.setAttribute("dto", dto);
			req.setAttribute("cardName", cardName);
			req.setAttribute("cAccount", cAccount);
			req.setAttribute("payDay", payDay);
			dao.updatePayDay(dto);
			
			url = "/aMr/userMyPage.jsp";
			forward(req, resp, url);
			
		} else if(uri.indexOf("list_cAccount.do") != -1) {
			
			String id = req.getParameter("id");
			
			MyCardDAO dao = new MyCardDAO(conn);
			MyCardDTO dto = dao.getReadData(id);
			
			String pageNum = req.getParameter("pageNum");

			int currentPage = 1;
			
			if(pageNum != null) {
				currentPage = Integer.parseInt(pageNum);
			}
			
			int cardCount = dao.getCardCount(id);
			
			int numPerPage = 3;
			int totalPage = myUtil.getPageCount(numPerPage, cardCount);
			
			if(currentPage > totalPage)
				currentPage = totalPage;
			
			int start = (currentPage - 1) * numPerPage + 1;
			int end = currentPage * numPerPage;
			
			List<MyCardDTO> lists = dao.getLists(start, end, id);
			
			String param = "";
			
			String listUrl = cp + "/mr/list_cAccount.do";
			
			if(!param.equals(""))
				listUrl = listUrl + "?" + param;
			
			String pageIndexList = myUtil.pageIndexList(currentPage, totalPage, listUrl);
			
			String articleUrl = cp + "/mr/list_cAccount.do?pageNum=" + currentPage;
			
			if(!param.equals("")) {
				articleUrl = articleUrl + "&" + param;
			}
			
			req.setAttribute("lists", lists);
			req.setAttribute("pageIndexList", pageIndexList);
			req.setAttribute("cardCount", cardCount);
			req.setAttribute("articleUrl", articleUrl);
			
			url = "/aMr/cAccountPage.jsp";
			forward(req, resp, url);
			
		} else if(uri.indexOf("list_cAccount_ok.do") != -1) {
			
			String id = req.getParameter("id");
			String cAccount = req.getParameter("cAccount");
			
			MyCardDAO dao = new MyCardDAO(conn);
			MyCardDTO dto = new MyCardDTO();
			
			int cardCount = dao.getCardCount(id);
			int payDay = dao.getpayDay(id);
			String cardName = dao.getcardName(id);
			
			req.setAttribute("cardCount", cardCount);
			req.setAttribute("payDay", payDay);
			req.setAttribute("dto", dto);
			req.setAttribute("cardName", cardName);
			req.setAttribute("cAccount", cAccount);
			
			dto.setcAccount(req.getParameter("cAccount"));
			dto.setCardName(req.getParameter("cardName"));
			dto.setId(req.getParameter("id"));
			
			dao.updatecAccount(dto);
			
			url = "/aMr/userMyPage.jsp";
			forward(req, resp, url);
			
		} else if(uri.indexOf("mrPay.do") != -1) {
			
			url = "/aMr/mrPay.jsp";
			forward(req, resp, url);
		} else if(uri.indexOf("cardForm.do") != -1) {
			
			String cardName = req.getParameter("cardName");
			HttpSession session = req.getSession();
			
			CustomInfo info = (CustomInfo)session.getAttribute("customInfo"); // Ŭ�������� �̷��� ���
			
			if(info == null) {
				url = "/aMr/login.jsp";
				forward(req, resp, url);
				return;
			}
			req.setAttribute("cardName", cardName);
			url = "/aMr/cardForm.jsp";
			forward(req, resp, url);
		

		}else if(uri.indexOf("cardForm_ok.do") != -1) {
			CardFormDAO dao = new CardFormDAO(conn);
			
			HttpSession session = req.getSession();
			CustomInfo info = (CustomInfo)session.getAttribute("customInfo"); // Ŭ�������� �̷��� ���
			CardFormDTO dto = new CardFormDTO();

			String cardName = req.getParameter("cardName");
			if(cardName == null || cardName.equals("")) {
				url = "/aMr/cardDetails.jsp";
				forward(req, resp, url);
			}
			dto.setId(info.getId());
			dto.setPayDay(Integer.parseInt(req.getParameter("payDay")));
			dto.setcPwd(req.getParameter("cPwd"));
			dto.setCardName(cardName);
			dto.setaTrans(req.getParameter("aTrans"));
			dto.setcAccount(req.getParameter("cAccount"));
			dto.setLimit(Integer.parseInt(req.getParameter("limit")));

			dao.insertData(dto);

			url="/mr/cardDetails.do?cardName=" + cardName;
			resp.sendRedirect(url);
		}
	}
}


