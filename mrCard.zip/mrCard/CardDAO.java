package com.mrCard;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CardDAO {
	private Connection conn = null;
	public CardDAO(Connection conn) {
		this.conn = conn;
	}
	//�˻� ���
	public List<CardDTO> getLists(){
		List<CardDTO> lists = new ArrayList<CardDTO>();
		CardDTO dto = null; 
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			sql = "select cardName, ptrans, mart, cstore, dstore, cafe, ";
			sql += "pgas, amf from cardInfo";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				dto = new CardDTO();
				dto.setCardName(rs.getString("cardName"));
				dto.setPtrans(rs.getInt("ptrans"));
				dto.setMart(rs.getInt("mart"));
				dto.setCstore(rs.getInt("cstore"));
				dto.setDstore(rs.getInt("dstore"));
				dto.setDstore(rs.getInt("cafe"));
				dto.setPgas(rs.getInt("pgas"));
				dto.setAmf(rs.getInt("amf"));
				
				lists.add(dto);
			}
			rs.close();
			pstmt.close();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return lists;
	}
	public List<CardDTO> getLists(String searchKey){
		List<CardDTO> lists = new ArrayList<CardDTO>();
		CardDTO dto = null; 
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			sql = "select cardName, ptrans, mart, cstore, dstore, cafe, ";
			sql += "pgas, amf from cardInfo where " + searchKey + " > 0";
			sql += "order by " + searchKey + " desc";
			// where cardName is " + cardName
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				dto = new CardDTO();
				dto.setCardName(rs.getString("cardName"));
				dto.setPtrans(rs.getInt("ptrans"));
				dto.setMart(rs.getInt("mart"));
				dto.setCstore(rs.getInt("cstore"));
				dto.setDstore(rs.getInt("dstore"));
				dto.setDstore(rs.getInt("cafe"));
				dto.setPgas(rs.getInt("pgas"));
				dto.setAmf(rs.getInt("amf"));
				
				lists.add(dto);
			}
			rs.close();
			pstmt.close();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return lists;
	}
}
