package com.mrCard;

public class MyCardDTO {
	
	private String id;
	private String createDay;
	private int payDay;
	private String cNum;
	private String cPwd;
	private String cvc;
	private String fDate;
	private String aTrans;
	private String cardName;
	private String cAccount;
	private String limit;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCreateDay() {
		return createDay;
	}
	public void setCreateDay(String createDay) {
		this.createDay = createDay;
	}
	public int getPayDay() {
		return payDay;
	}
	public void setPayDay(int payDay) {
		this.payDay = payDay;
	}
	public String getcNum() {
		return cNum;
	}
	public void setcNum(String cNum) {
		this.cNum = cNum;
	}
	public String getcPwd() {
		return cPwd;
	}
	public void setcPwd(String cPwd) {
		this.cPwd = cPwd;
	}
	public String getCvc() {
		return cvc;
	}
	public void setCvc(String cvc) {
		this.cvc = cvc;
	}
	public String getfDate() {
		return fDate;
	}
	public void setfDate(String fDate) {
		this.fDate = fDate;
	}
	public String getaTrans() {
		return aTrans;
	}
	public void setaTrans(String aTrans) {
		this.aTrans = aTrans;
	}
	public String getCardName() {
		return cardName;
	}
	public void setCardName(String cardName) {
		this.cardName = cardName;
	}
	public String getcAccount() {
		return cAccount;
	}
	public void setcAccount(String cAccount) {
		this.cAccount = cAccount;
	}
	public String getLimit() {
		return limit;
	}
	public void setLimit(String limit) {
		this.limit = limit;
	}
	
	
	
}