package com.mrCard;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class loginDAO {

	private Connection conn;
	
	public loginDAO(Connection conn) {
		this.conn = conn;
	}
	

	public int insertData(loginDTO dto) {
		
		int result = 0;
		
		PreparedStatement pstmt = null;
		String sql;
		
		try {
			
			sql = "insert into userInfo (id,pwd,name,address,jumin) values (?,?,?,?,?)";			
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, dto.getId());
			pstmt.setString(2, dto.getPwd());
			pstmt.setString(3, dto.getName());
			pstmt.setString(4, dto.getAddress());
			pstmt.setString(5, dto.getJumin());
						
			result = pstmt.executeUpdate();
			
			pstmt.close();						
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}		
		return result;		
	}
	
	
	public loginDTO getReadData(String id) {
		
		loginDTO dto = null;
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			sql = "select id,pwd,name,address,jumin from userInfo where id=?";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, id);
					
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				dto = new loginDTO();
				
				dto.setId(rs.getString("id"));
				dto.setPwd(rs.getString("pwd"));
				dto.setName(rs.getString("name"));
				dto.setAddress(rs.getString("address"));
				dto.setJumin(rs.getString("jumin"));
				
			}
			
			rs.close();
			pstmt.close();
						
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return dto;
		
	}
	
public loginDTO getReadData2(String name) {
		
		loginDTO dto = null;
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			sql = "select id,pwd,name,address,jumin from userInfo where name=?";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, name);
					
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				dto = new loginDTO();
				
				dto.setName(rs.getString("name"));
				dto.setId(rs.getString("id"));
				dto.setPwd(rs.getString("pwd"));
				dto.setName(rs.getString("name"));
				dto.setAddress(rs.getString("address"));
				dto.setJumin(rs.getString("jumin"));
				
			}
			
			rs.close();
			pstmt.close();
						
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return dto;
		
	}

	
	
	


}