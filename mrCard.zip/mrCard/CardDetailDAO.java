package com.mrCard;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

	public class CardDetailDAO {
	
	private Connection conn;
	
	public CardDetailDAO(Connection conn) {
		this.conn = conn;
	}
	
	public CardDetailDTO getCardDetail(String cardName) {
		
		CardDetailDTO dto = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql; 
		
		try {
			
			sql = "select cardName,pTrans,mart,cStore,dStore,cafe,pGas,amf ";
			sql += "where cardName=?";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, cardName);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				dto = new CardDetailDTO();
				
				dto.setCardName(rs.getString("cardName"));
				dto.setpTrans(rs.getInt("pTrans"));
				dto.setMart(rs.getInt("mart"));
				dto.setcStore(rs.getInt("cStore"));
				dto.setdStore(rs.getInt("dStore"));
				dto.setCafe(rs.getInt("cafe"));
				dto.setpGas(rs.getInt("pGas"));
				dto.setAmf(rs.getInt("amf"));
				
			}
			
			rs.close();
			pstmt.close();
			
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		
		return dto;
		
	}

	
	

}
