package com.mrCard;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.Random;

//ī�� ��û ��
public class CardFormDAO {
	
	Connection conn = null;
	public CardFormDAO(Connection conn) {
		this.conn = conn;
	}
	//ī���ȣ
	public String getCnum() {
		Random rd = new Random();
		String cNum = "";
		
		int n = 0;
		while(n<16) {
			cNum += "" + rd.nextInt(10);//0~9������ ��
			n++;
		}
		return cNum;
	}
	
	//cvc
	public String getCvc() {
		Random rd = new Random();
		String cvc = "";
		
		int n = 0;
		while(n<3) {
			cvc += "" + rd.nextInt(10);//0~9������ ��
			n++;
		}
		return cvc;
	}
	
	//���� �ּ� ��������
	public String getAddress(String id) {
		String address = "";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		try {
			sql = "select address from userInfo where id = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				address = rs.getString("address");
			}
			rs.close();
			pstmt.close();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return address;
	}
	
	public int insertData(CardFormDTO dto) {
		int result = 0;
		PreparedStatement pstmt = null;
		String sql;
		try {
			sql = "insert into userCard(id, createDay, payDay, cNum, cPwd, cvc, ";
			sql += "fDate, cardName, aTrans, cAccount, limit) ";
			sql += "values (?, sysdate, ?, ?, ?, ?, ADD_MONTHS(sysdate, 12*5), ?, ?, ?, ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getId());
			pstmt.setInt(2, dto.getPayDay());
			pstmt.setString(3, getCnum());
			pstmt.setString(4, dto.getcPwd());
			pstmt.setString(5, getCvc());
			
			pstmt.setString(6, dto.getCardName());
			pstmt.setString(7, dto.getaTrans());
			pstmt.setString(8, dto.getcAccount());
			pstmt.setInt(9, dto.getLimit());
			
			result = pstmt.executeUpdate();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return result;
	}
}
