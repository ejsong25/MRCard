package com.mrCard;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

import javax.mail.Session;
import javax.servlet.http.HttpSession;

public class CardFormDAO {

private Connection conn;
	
	public CardFormDAO(Connection conn) {
		this.conn = conn;
	}
	

	
	//ī���ȣ
	public String getCnum() {
		Random rd = new Random();
		String cNum = "";
		
		int n = 0;
		while(n<16) {
			cNum += "" + rd.nextInt(10);//0~9������ ��
			n++;
		}
		return cNum;
	}
	
	//cvc
	public String getCvc() {
		Random rd = new Random();
		String cvc = "";
		
		int n = 0;
		while(n<3) {
			cvc += "" + rd.nextInt(10);//0~9������ ��
			n++;
		}
		return cvc;
	}
	
	public int insertData(CardFormDTO dto) {
		int result = 0;
		PreparedStatement pstmt = null;
		String sql;
		try {
			sql = "insert into userCard(id, createDay, payDay, cNum, cPwd, cvc, ";
			sql += "fDate, cardName, aTrans, cAccount, limit) ";
			sql += "values (?, sysdate, ?, ?, ?, ?, ADD_MONTHS(sysdate, 12*5), ?, ?, ?, ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getId());
			pstmt.setInt(2, dto.getPayDay());
			pstmt.setString(3, getCnum());
			pstmt.setString(4, dto.getcPwd());
			pstmt.setString(5, getCvc());
			
			pstmt.setString(6, dto.getCardName());
			pstmt.setString(7, dto.getaTrans());
			pstmt.setString(8, dto.getcAccount());
			pstmt.setInt(9, dto.getLimit());
			
			result = pstmt.executeUpdate();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return result;
	}


//	public int insertData(CardFormDTO dto ) {
//		
//		int result = 0;
//
//		
//		
//		String fDate = yearLater();
//		
//		String cNum = getCnum();
//		
//		String cvc = getCvc();
//		
//		PreparedStatement pstmt = null;
//		String sql;
//		
//		try {
//			
//			sql = "insert into userCard (id,cardName,cPwd,cAccount,aTrans,'limit',payDay,createDay,cNum,cvc,fDate) ";
//			sql += "values (?,?,?,?,?,?,?,sysdate,?,?,?)";
//			
//			pstmt = conn.prepareStatement(sql);
//			
//			pstmt.setString(1, dto.getId());
//			pstmt.setString(2, dto.getCardName());
//			pstmt.setString(3, dto.getcPwd());
//			pstmt.setString(4, dto.getcAccount());
//			pstmt.setString(5, dto.getaTrans());
//			pstmt.setInt(6, dto.getLimit());
//			pstmt.setInt(7, dto.getPayDay());			
//			pstmt.setString(8, cNum);
//			pstmt.setString(9, cvc);
//			pstmt.setString(10, fDate);
//			
//			result = pstmt.executeUpdate();
//			
//			pstmt.close();
//		} catch (Exception e) {
//			System.out.println(e.toString());
//		}		
//		return result;		
//	}
}
		