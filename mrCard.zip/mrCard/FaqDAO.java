package com.mrCard;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class FaqDAO {

	private Connection conn = null;

	public FaqDAO(Connection conn) {
		this.conn = conn;
	}

	//�˻� ���
	public List<FaqDTO> getLists(){

		List<FaqDTO> lists = new ArrayList<FaqDTO>();

		FaqDTO dto = null; 
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;

		try {
			sql = "select subject, content from faq";

			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while(rs.next()) {
				dto = new FaqDTO();

				dto.setSubject(rs.getString("subject"));
				dto.setContent(rs.getString("content"));

				lists.add(dto);
			}
			rs.close();
			pstmt.close();

		} catch (Exception e) {
			System.out.println(e.toString());
		}

		return lists;
	}

	public List<FaqDTO> getLists(String searchKey){

		List<FaqDTO> lists = new ArrayList<FaqDTO>();

		FaqDTO dto = null; 
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;

		try {
			sql = "select subject, content from faq ";
			sql += "where key = '" + searchKey + "'";

			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while(rs.next()) {

				dto = new FaqDTO();
				dto.setSubject(rs.getString("subject"));
				dto.setContent(rs.getString("content"));

				lists.add(dto);
			}

			rs.close();
			pstmt.close();

		} catch (Exception e) {
			System.out.println(e.toString());
		}

		return lists;
	}

}
