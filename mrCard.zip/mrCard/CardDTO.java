package com.mrCard;

public class CardDTO {
	
	String cardName;
	int ptrans;
	int mart;
	int cstore;
	int dstore;
	int cafe;
	int pgas;
	int amf;
	
	public String getCardName() {
		return cardName;
	}
	public void setCardName(String cardName) {
		this.cardName = cardName;
	}
	public int getPtrans() {
		return ptrans;
	}
	public void setPtrans(int ptrans) {
		this.ptrans = ptrans;
	}
	public int getMart() {
		return mart;
	}
	public void setMart(int mart) {
		this.mart = mart;
	}
	public int getCstore() {
		return cstore;
	}
	public void setCstore(int cstore) {
		this.cstore = cstore;
	}
	public int getDstore() {
		return dstore;
	}
	public void setDstore(int dstore) {
		this.dstore = dstore;
	}
	public int getCafe() {
		return cafe;
	}
	public void setCafe(int cafe) {
		this.cafe = cafe;
	}
	public int getPgas() {
		return pgas;
	}
	public void setPgas(int pgas) {
		this.pgas = pgas;
	}
	public int getAmf() {
		return amf;
	}
	public void setAmf(int amf) {
		this.amf = amf;
	}
}
