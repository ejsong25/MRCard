package com.mrCard;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class MyPageDAO {
	
private Connection conn;
	
	public MyPageDAO(Connection conn) {
		this.conn = conn;
	}
	
	//������ �б�
	public loginDTO getReadData(String id) {
		
		loginDTO dto = null;
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			sql = "select id,pwd,name,jumin from userInfo where id=?";
						
			pstmt = conn.prepareStatement(sql);
						
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				dto = new loginDTO();
				
				dto.setId(rs.getString("id"));
				dto.setPwd(rs.getString("pwd"));
				dto.setName(rs.getString("name"));
				dto.setJumin(rs.getString("jumin"));

			}
			
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return dto;
	}
	
	//����
	public int updateData(loginDTO dto) {
		
		int result = 0;

		PreparedStatement pstmt = null;
		String sql;
		
		try {
			
			sql = "update userInfo set pwd=?,name=? ";
			sql+= "where id=?";
			
			pstmt = conn.prepareStatement(sql);
			
			
			pstmt.setString(1, dto.getPwd());
			pstmt.setString(2, dto.getName());
			pstmt.setString(3, dto.getId());
			
			result = pstmt.executeUpdate();

			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return result;
	}
	

}
