package com.mrCard;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.board.BoardDTO;
import com.naver.NaverDTO;

public class MyCardDAO {

	private Connection conn = null;

	public MyCardDAO(Connection conn) {
		this.conn = conn;
	}

	// ��ü ī�� ����
	public int getCardCount(String id) {

		int cardCount = 0;

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;

		try {

			sql = "select nvl(count(*),0) from userCard where id=?";

			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, id);

			rs = pstmt.executeQuery();

			if(rs.next()) {

				cardCount = rs.getInt(1);

			}
			rs.close();
			pstmt.close();

		} catch (Exception e) {
			System.out.println(e.toString());
		}

		return cardCount;

	}

	// num�� �ִ����� ī���̸� ��������
	public String getcardName(String id) {

		String cardName = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;

		try {

			sql = "select cardName from userCard where id=? ";
			sql += "and createDay=(select max(createDay) from userCard where id=?)";

			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, id);
			pstmt.setString(2, id);

			rs = pstmt.executeQuery();

			if(rs.next()) {

				cardName = rs.getString(1); // ������ �÷� �ϳ� �����µ� �Ļ��÷��̶� 1 ����

			}

			rs.close();
			pstmt.close();


		} catch (Exception e) {
			System.out.println(e.toString());
		}

		return cardName;
	}

	// num�� �ִ����� ���¹�ȣ ��������
	public String getcAccount(String id) {

		String cAccount = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;

		try {

			sql = "select cAccount from userCard where id=? ";
			sql += "and createDay=(select max(createDay) from userCard where id=?)";

			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, id);
			pstmt.setString(2, id);

			rs = pstmt.executeQuery();

			if(rs.next()) {

				cAccount = rs.getString(1); // ������ �÷� �ϳ� �����µ� �Ļ��÷��̶� 1 ����

			}

			rs.close();
			pstmt.close();


		} catch (Exception e) {
			System.out.println(e.toString());
		}

		return cAccount;
	}

	//������ ��������
	public int getpayDay(String id) {

		int payDay = 0;

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;

		try {

			sql = "select payDay from userCard where id=?";

			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, id);

			rs = pstmt.executeQuery();

			if(rs.next()) {

				payDay = rs.getInt(1);

			}
			rs.close();
			pstmt.close();

		} catch (Exception e) {
			System.out.println(e.toString());
		}

		return payDay;
	}

	// ������ ������ ��������
	public MyCardDTO getReadData(String id) {

		MyCardDTO dto = null;

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;

		try {

			sql = "select id,payDay,cAccount from userCard where id=?";

			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, id);

			rs = pstmt.executeQuery();

			if(rs.next()) {

				dto = new MyCardDTO();

				dto.setId(rs.getString("id"));
				dto.setPayDay(rs.getInt("payDay"));
				dto.setcAccount(rs.getString("cAccount"));
			}

			rs.close();
			pstmt.close();

		} catch (Exception e) {

		}

		return dto;

	}

	// ������ ����
	public int updatePayDay(MyCardDTO dto) {

		int result = 0;

		PreparedStatement pstmt = null;
		String sql;

		try {

			sql = "update userCard set payDay=? where id=?";

			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, dto.getPayDay());
			pstmt.setString(2, dto.getId());

			result = pstmt.executeUpdate();

			pstmt.close();

		} catch (Exception e) {
			System.out.println(e.toString());
		}

		return result;
	}
	
	public String getName(String id) {
		
		String name = "";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			sql = "select name from userInfo where id = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				name = rs.getString("name");
			}
			rs.close();
			pstmt.close();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return name;
	}
	
	public List<MyCardDTO> getLists(int start, int end,String id) {
		
		List<MyCardDTO> lists = new ArrayList<MyCardDTO>();
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			sql = "select * from (";
			sql+= "select rownum rnum, data.* from(";
			sql+= "select cradName,cNum,cAccount, ";
			sql+= "to_char(createDay,'YY-MM') createDay ";
			sql+= "from userCard where id=? order by createDay) data) ";
			sql+= "where rnum>=? and rnum<=?";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1,id);
			pstmt.setInt(2, start);
			pstmt.setInt(3, end);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				MyCardDTO dto = new MyCardDTO();
				
				dto.setCardName(rs.getString("cardName"));
				dto.setcNum(rs.getString("cNum"));
				dto.setcAccount(rs.getString("cAccount"));
				dto.setCreateDay(rs.getString("createDay"));
				
				lists.add(dto);
				
			}
			rs.close();
			pstmt.close();

		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return lists;
	}

}
