package com.mrCard;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class SignUpDAO {

	
	private Connection conn;
	
	public SignUpDAO(Connection conn) {
		this.conn = conn;
	}
	
	public int insertData(SignUpDTO dto) {
		
		int result = 0;
		
		PreparedStatement pstmt = null;
		String sql;
		
		try {
			
			sql = "insert into userInfo (id,pwd,name,jumin) ";
			sql += "values (?,?,?,?)";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, dto.getId());
			pstmt.setString(2, dto.getPwd());
			pstmt.setString(3, dto.getName());
			pstmt.setString(4, dto.getJumin());
				
			result = pstmt.executeUpdate();
			
			pstmt.close();						
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}		
		return result;		
	}
		
	
	
	
	
}
